import 'dart:io';

String fileName(String path) => path.split(Platform.pathSeparator).last;
