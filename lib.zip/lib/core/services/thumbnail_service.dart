import 'dart:async';
import 'dart:typed_data';

import 'package:media_kit/media_kit.dart';

class ThumbnailService {
  ThumbnailService._();

  static final ThumbnailService instance = ThumbnailService._();

  final Map<String, Future<Uint8List?>> _cache = {};

  Future<Uint8List?> thumbnail(String path) {
    return _cache.putIfAbsent(path, () => _create(path));
  }

  Future<Uint8List?> _create(String path) async {
    final player = Player();
    try {
      await player.open(Media(path), play: false);
      await player.stream.width
          .firstWhere((value) => value != null && value > 0)
          .timeout(const Duration(seconds: 4));
      return await player.screenshot(format: 'image/jpeg');
    } catch (_) {
      return null;
    } finally {
      await player.dispose();
    }
  }

  void clear(String path) {
    _cache.remove(path);
  }
}
